package com.nictice.myapplication.screens

import android.util.Log
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.runtime.Composable
import com.nictice.myapplication.Joke1

import com.nictice.myapplication.MainActivity
import com.nictice.myapplication.data.JokesViewModelInterface
import com.nictice.myapplication.models.JokeModel

public @Composable
fun ShowJokesScreen(viewModel: JokesViewModelInterface) {
    var jokes = viewModel.jokesList

        LazyColumn {
            items(jokes.size) {
                //Joke2(jokeModel = jokes[index], context = LocalContext.current
                    index -> Joke1(jokeModel = jokes[index])
            {
                Log.d("ShowJokesScreen", "You clicked joke number: ${jokes[index]}")
                Log.d("Joke Tag", "You clicked : $index")
                viewModel.hikeShowJoke(jokes[index])

            }
            }
        }
}